// Declare the Setup function

function setup() {

// create a canvas 1280 px wide, by 720 px high

  createcanvas( 1280, 720);


//color background 'grey'

background( 'grey');
/*
// create initial 'body' of monster. using an elongated oval, or ellipse
function draw(){
fill( 'Light Brown');
ellipse( 20, 20, 20, 51);


  // creates an ellipse, that's taller, than it is wide.

    fill( 'Light brown');
    ellipse( 25, 16, 20, 51);

// create a series of ellipses for left arm

  fill( 'Light brown');
  ellipse( 25, 16, 20, 51);

// create series of ellipses for right arm.

fill( 'Light Brown');
  ellipse( 65, 65, 20, 51);

// create ellipses for left leg.

fill( 'Light Brown');
ellipse( 75, 75, 20, 58);

fill( 'Light Brown');
  ellipse( 80, 80, 20, 58);

// create ellipses for right leg.

fill( 'Light Brown');
  ellipse( 90, 90, 20, 58);


//Create circle for head. (almost forgot!!)


  fill( 'Red');
  ellipse( 15, 15, 60, 60 );
*/
  
}
